YENİ 100 SİTELİK GÖREV — 60 SİTELİK ARA KAYIT

Nihai teslim değildir: 60 site, 480 alt sayfa tamamlandı.
Diğer 40 site ve 320 sayfa bu arşivde yer almaz.
Bu dosya tamamlanan sitelerin toplu ara teslimidir.

Adana A'nın yeni sekiz alt sayfası ilk dosyadır. Bu dosyadan kendisini
tanımlayan tek açıklama cümlesi çıkarılarak son talimatla uyum sağlandı;
önceki kaynak dosya korunmuştur. Diğer dosyalar son 99 maddelik listeden
üretilir. Paralel çalışılan grupların tamamlananları sayısal sırayla ZIP'e
eklenir; boş veya otomatik doldurulmuş site dosyası kullanılmaz.

Her alan adı için bir UTF-8 TXT bulunur. Sayfalar ===== ile ayrılır.
Ana sayfa yoktur. Önceki 1.600 sayfalık arşiv bu pakete eklenmemiştir.

Kontroller: Her içerik en az 1.500 harf; SEO en çok 60 ve meta en çok
155 karakter. Başlıklar, SEO alanları, son hekim notu, boşluk, rakam ve
noktalama harf hesabının dışındadır. Her beşinci sayfada en az sekiz
yerel soru bulunur. A/B ilçeleri görev listesinde farklı atanmıştır.

Kaydedilen önceki ve yeni metinlerde aynı tam cümle, paragraf veya alt
başlık bulunmadı. Zorunlu son hekim notu bu karşılaştırmanın dışındadır.
Bu denetim ortak tıbbi kavram olmadığına dair iddia değildir.
Metinler kişisel tanı veya reçetenin yerine kullanılamaz.

PAKET-ILERLEMESI.json kalan numaraları, GOREV-LISTESI.json ise domain,
versiyon, konu seti ve ilçeleri gösterir. Devam ederken tamamlanmış
dosyalar yeniden üretilmeden bu kayıtlar esas alınabilir.
