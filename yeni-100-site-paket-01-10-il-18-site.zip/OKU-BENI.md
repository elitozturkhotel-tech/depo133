YENİ 100 SİTELİK GÖREV — PAKET 1

Bu ZIP 10 il, 18 site ve 144 yeni alt sayfa içerir.
İller: Adana, Adıyaman, Afyonkarahisar, Ağrı, Amasya, Antalya, Artvin, Aydın, Balıkesir, Bilecik.
Bu arşiv yalnızca belirtilen illerin dosyalarını içerir; diğer paketlerin kopyalarını içermez.
Her site için sekiz alt sayfa vardır; ana sayfalar bu görevin kapsamına girmez.

Her alan adı bir UTF-8 TXT dosyasıdır. Sekiz sayfa ===== satırı ile ayrılır.
SITE-SIRASI.csv, dosyaların il, A/B, ilçe ve konu eşleştirmesini gösterir.
HARF-KONTROLU.csv, başlıklar, SEO alanları ve zorunlu hekim notu dışında
hesaplanan alfabetik harf sayılarını gösterir. Her içerik en az 1500 harftir.
SEO başlıkları en çok 60, meta açıklamaları en çok 155 karakterdir.

Tam cümle, paragraf ve alt başlık eşleşmesi önceki kayıtlı içeriklerle ve yeni
paketin dosyaları arasında tarandı. Zorunlu hekim notu bunun dışındadır.
İçerik tıbbi muayenenin yerine geçmez; yayın öncesi uzman incelemesi önerilir.
